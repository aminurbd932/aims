<section class="content-header">
      <h1 class="custom-breadcum">
        Department
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/department')}}"></i> Department</a></li>
        <li class="active">Department {{ $bc_title }}</li>
      </ol>
</section>