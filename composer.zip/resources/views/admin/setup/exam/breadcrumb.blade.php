<section class="content-header">
      <h1 class="custom-breadcum">
        Exam
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/exam')}}"></i> Exam</a></li>
        <li class="active">Exam {{ $bc_title }}</li>
      </ol>
</section>