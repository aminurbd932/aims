<section class="content-header">
      <h1 class="custom-breadcum">
        Generic Name
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/generic-product')}}"></i> Generic Name</a></li>
        <li class="active">Generic Name {{ $bc_title }}</li>
      </ol>
</section>