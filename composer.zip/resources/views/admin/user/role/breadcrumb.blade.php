<section class="content-header">
      <h1 class="custom-breadcum">
        Role
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> User</a></li>
        <li><a href="{{url('/admin/role')}}"></i> Role</a></li>
        <li class="active">Role {{ $bc_title }}</li>
      </ol>
</section>