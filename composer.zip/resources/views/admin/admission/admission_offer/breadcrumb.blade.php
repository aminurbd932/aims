<section class="content-header">
      <h1 class="custom-breadcum">
        Admission Offer
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/admission-offer')}}"></i> Admission Offer</a></li>
        <li class="active">Admission Offer {{ $bc_title }}</li>
      </ol>
</section>