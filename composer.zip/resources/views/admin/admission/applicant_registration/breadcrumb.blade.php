<section class="content-header">
      <h1 class="custom-breadcum">
        Applicant Registration
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/applicant-registration')}}"></i> Applicant Registration</a></li>
        <li class="active">Applicant Registration {{ $bc_title }}</li>
      </ol>
</section>