$(document).on('click','.data-delete-btn', function(e){
	e.preventDefault();
	_this = $(this);
	var _closest = _this.closest('tr');
	var targetUrl = base_url+_this.attr('data-href');
	var _token = $("input[name='_token']").val();
	var sendData = {_token:_token};
	swal(getSwalTitle()).then(function () {
		//console.log('yes');
    	$.ajax({
            url: targetUrl,
            type: "POST",
            data: sendData,
             dataType: 'json',
            success: function (response) {
            	if (response.success == true) {
            		showAlertMessage('Success...', response.message, 'success');
            		_closest.fadeOut(1000, function () {
	    	  			$(this).remove();
	    			});
            	}

            	if (response.success == false) {
            		showAlertMessage('Unsuccess...', response.message, 'warning');
            	}
          }, error: function (jqXHR) {
            showAlertMessage('Error...', jqXHR, 'error');
          }
      });
    }, function (dismiss) {

        swalCancelConfirm(dismiss);
    });
});


$(document).on('click','.data-view-btn', function(e){
        e.preventDefault();
        _this = $(this);
        var _closest = _this.closest('tr');
        var targetUrl = base_url+_this.attr('data-href');
        var _token = $("input[name='_token']").val();
        var sendData = {_token:_token};
        
        modalShow("Admision Exam View", "");
        $.post( targetUrl, sendData).done( function( resp ) { 
            $('#commonModalBody').html(resp);
        }); 
    });

           /*            input mark        */

$(document).on('keyup','table.com_table .input-mark', function(){
     _this = $(this);
     var _closest = _this.closest('tr');
    var sum = 0;
    _closest.find(".input-mark").each(function(){
        this_mark = parseFloat(+$(this).val());
        if(isNaN(this_mark) || this_mark == '') {
            this_mark = 0;
        }
        sub_mark = parseFloat($(this).attr('subject_mark'));
        if (sub_mark < this_mark) {
            this_mark = 0;
            $(this).val('0');
        }
        sum += this_mark;
    });
    _closest.find(".total-mark").val(sum);
});


 /*           edit input mark        */

$(document).on('keyup','table.edit_com_table .input-mark', function(){
     _this = $(this);
     var _closest = _this.closest('tr');
    var sum = 0;
    $(".input-mark").each(function(){
        this_mark = parseFloat(+$(this).val());
        if(isNaN(this_mark) || this_mark == '') {
            this_mark = 0;
        }
        sub_mark = parseFloat($(this).attr('subject_mark'));
        if (sub_mark < this_mark) {
            this_mark = 0;
            $(this).val('0');
        }
        sum += this_mark;
    });
    $(".total-mark").val(sum);
});


                /*         search admission offer           */

$('form.search_form').validator().on('submit', function(e){
    if (!e.isDefaultPrevented()) {
        e.preventDefault();
        $("input[type = 'submit']").prop('disabled', true);
        var sendData = $(this).serialize();
        var targetUrl = $(this).attr('action');
        $.ajax({
            url: targetUrl,
            type: "POST",
            data: sendData,
             dataType: 'json',
            success: function (response) {
               // console.log("response"+response);
                if (response.success == 2) {
                    showAlertMessage('Success...', response.message, 'success');
                }
                $('.list-container').html(response);

                if (response.success == false) {
                    showAlertMessage('Unsuccess...', response.message, 'warning');
                }
          }, error: function (jqXHR) {
            showAlertMessage('Error...', jqXHR, 'error');
          }
      });
    }
});