$(document).on('click','.data-delete-btn', function(e){
	e.preventDefault();
	_this = $(this);
	var _closest = _this.closest('tr');
	var targetUrl = base_url+_this.attr('data-href');
	var _token = $("input[name='_token']").val();
	var sendData = {_token:_token};
	swal(getSwalTitle()).then(function () {
		//console.log('yes');
    	$.ajax({
            url: targetUrl,
            type: "POST",
            data: sendData,
             dataType: 'json',
            success: function (response) {
            	if (response.success == true) {
            		showAlertMessage('Success...', response.message, 'success');
            		_closest.fadeOut(1000, function () {
	    	  			$(this).remove();
	    			});
            	}

            	if (response.success == false) {
            		showAlertMessage('Unsuccess...', response.message, 'warning');
            	}
          }, error: function (jqXHR) {
            showAlertMessage('Error...', jqXHR, 'error');
          }
      });
    }, function (dismiss) {

        swalCancelConfirm(dismiss);
    });
});


$(document).on('click','.data-view-btn', function(e){
        e.preventDefault();
        _this = $(this);
        var _closest = _this.closest('tr');
        var targetUrl = base_url+_this.attr('data-href');
        var _token = $("input[name='_token']").val();
        var sendData = {_token:_token};
        
        modalShow("Applicant Result View", "");
        $.post( targetUrl, sendData).done( function( resp ) { 
            $('#commonModalBody').html(resp);
        }); 
    });


                /*         search admission offer           */

$('form.search_form').validator().on('submit', function(e){
    if (!e.isDefaultPrevented()) {
        e.preventDefault();
        $("input[type = 'submit']").prop('disabled', true);
        var sendData = $(this).serialize();
        var targetUrl = $(this).attr('action');
        $.ajax({
            url: targetUrl,
            type: "POST",
            data: sendData,
             dataType: 'json',
            success: function (response) {
                console.log("response"+response);
                if (response.success == 2) {
                    showAlertMessage('Success...', response.message, 'success');
                }
                $('.list-container').html(response);

                if (response.success == false) {
                    showAlertMessage('Unsuccess...', response.message, 'warning');
                }
          }, error: function (jqXHR) {
            showAlertMessage('Error...', jqXHR, 'error');
          }
      });
    }
});