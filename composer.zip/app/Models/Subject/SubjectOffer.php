<?php

namespace App\Models\Subject;

use Illuminate\Database\Eloquent\Model;

class SubjectOffer extends Model
{
    //
}
