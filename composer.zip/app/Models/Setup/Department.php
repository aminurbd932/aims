<?php

namespace App\Models\Setup;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Department extends Model
{
    protected $table ="departments";
    public $timestamps = true;
    protected $fillable=['name'];
    use SoftDeletes;
}
