<?php

namespace App\Models\Admission;

use Illuminate\Database\Eloquent\Model;

class AdmissionExamSubject extends Model
{
    protected $table ="admission_exam_subjects";
    public $timestamps = false;
}
