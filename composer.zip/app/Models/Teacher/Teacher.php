<?php

namespace App\Models\Teacher;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Teacher extends Model
{
	use SoftDeletes;
    public function programOffers()
    {
        return $this->hasMany('App\Models\Program\ProgramOffer','id','teacher_id');
    }
}
