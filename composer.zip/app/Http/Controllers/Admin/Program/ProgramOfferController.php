<?php

namespace App\Http\Controllers\Admin\Program;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Program\ProgramOffer;
use App\Models\Setup\ClassLevel;
use App\Models\Setup\Program;
use App\Models\Setup\Section;
use App\Models\Setup\Group;
use App\Models\Setup\Shift;
use App\Models\Setup\Medium;
use App\Models\Setup\Session;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\Admin\Program\ProgramOfferFormRequest as POFormRequest;

class ProgramOfferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->restriction('program-offer-view');
        $data = [];

        $data['page_scripts'] = array('admin/custom/js/program/program_offer.js');
        $data['bc_title'] = "List";
        $data['records'] = ProgramOffer::all();
        return view('admin.program.program_offer.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->restriction('program-offer-create');
        $data = [];
        $data = $this->getProgramOfferAllList();
        $data['bc_title'] = "Add";
        //echo '<pre>';print_r($data);exit;
        return view('admin.program.program_offer.add')->with($data);
    }

    private function getProgramOfferAllList()
    {
        $data['class_level_list'] = ClassLevel::all()->where('status', 1);
        $data['class_level_list']->prepend('Select');
        $data['program_list'] = Program::all()->where('status', 1);
        $data['program_list']->prepend('Select');
        $data['section_list'] = Section::all()->where('status', 1);
        $data['section_list']->prepend('Select');
        $data['group_list'] = Group::all()->where('status', 1);
        $data['group_list']->prepend('Select');
        $data['medium_list'] = Medium::all()->where('status', 1);
        $data['medium_list']->prepend('Select');
        $data['shift_list'] = Shift::all()->where('status', 1);
        $data['shift_list']->prepend('Select');
        return $data;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
