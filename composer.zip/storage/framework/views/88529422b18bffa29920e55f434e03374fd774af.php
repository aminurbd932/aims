<?php 
	$can_edit = Entrust::can('setup-department-edit');
	$can_status = Entrust::can('setup-department-status');
	$can_delete = Entrust::can('setup-department-delete');
?>
<div class="col-md-12">
	<div class="box">
		<div class="box-body">
			<table class="table table-bordered">
				<tbody>
					<tr class="active">
					  <th>#</th>
					  <th>Department Name</th>
					  <th>Status</th>
					  <?php if($can_edit || $can_status || $can_delete): ?>
					  <th>Action</th>
					  <?php endif; ?>
					</tr>
					<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="<?php echo e((($key+1) % 2 == 0) ? 'success' : 'primary'); ?>">
					  <td><?php echo e($key+1); ?></td>
					  <td><?php echo e($row->name); ?></td>
					  <td>
					  	  <div class="status_label">
						  <?php if($row->status == 1): ?>
						  	<span class="label label-success">Active</span>
						  <?php else: ?>
						  	<span class="label label-warning">Inactive</span>
						  <?php endif; ?>
						  </div>
					  </td>
					  <?php if($can_edit || $can_status || $can_delete): ?>
	                   <td style="text-align: center;width: 100px;">
	                   <?php if($can_status): ?>
	                   <span class="status">
	                   <?php if($row->status == 1): ?>
	                   	<?php echo Form::button('<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>' ,['class' => 'btn btn-success btn-xs data-inactive-btn','data-href' => '/admin/inactive-department/'.$row->id ]); ?>

	                   <?php else: ?>
	                   	<?php echo Form::button('<i class="fa fa-arrow-circle-up" aria-hidden="true"></i>' ,['class' => 'btn btn-danger btn-xs data-active-btn','data-href' => '/admin/active-department/'.$row->id ]); ?>

	                   <?php endif; ?>
	                   </span>
	                   <?php endif; ?>
	                   <?php if($can_edit): ?>
	                   <a href="<?php echo e(url('/admin/edit-department/'.$row->id)); ?>" class="btn btn-info btn-xs data-edit-btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
	                   <?php endif; ?>
	                   <?php if($can_delete): ?>
	                   <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i>' ,['class' => 'btn btn-danger btn-xs data-delete-btn','data-href' => '/admin/delete-department/'.$row->id ]); ?>

	                   <?php endif; ?>
	                   </td>
	                   <?php endif; ?>
					</tr>
				 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>