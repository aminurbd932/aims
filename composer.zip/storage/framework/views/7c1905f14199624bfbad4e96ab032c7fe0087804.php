<?php 
	$can_edit = Entrust::can('user-user-edit');
	$can_status = Entrust::can('user-user-status');
?>
<div class="col-md-12">
	<div class="box">
		<div class="box-body">
			<table class="table table-bordered">
				<tbody>
					<tr class="active">
					  <th>#</th>
					  <th>User Name</th>
					  <th>Email</th>
					  <th>Role Name</th>
					  <th>Status</th>
					  <?php if($can_edit || $can_status): ?>
					  <th>Action</th>
					  <?php endif; ?>
					</tr>
					<?php if($records): ?>
					<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="<?php echo e((($key+1) % 2 == 0) ? 'success' : 'primary'); ?>">
					  <td><?php echo e($key+1); ?></td>
					  <td><?php echo e($row->user_name); ?></td>
					  <td><?php echo e($row->email); ?></td>
					  <td><?php echo e($row->display_name); ?></td>
					  <td>
					  	  <div class="status_label">
						  <?php if($row->status == 1): ?>
						  	<span class="label label-success">Active</span>
						  <?php else: ?>
						  	<span class="label label-warning">Inactive</span>
						  <?php endif; ?>
						  </div>
					  </td>
					  <?php if($can_edit || $can_status): ?>
	                   <td style="text-align: center;width: 100px;">
	                   <?php if($can_status): ?>
	                   <span class="status">
	                   <?php if($row->status == 1): ?>
	                   	<?php echo Form::button('<i class="fa fa-arrow-circle-down" aria-hidden="true"></i>' ,['class' => 'btn btn-success btn-xs data-inactive-btn','data-href' => '/admin/inactive-user/'.$row->id ]); ?>

	                   <?php else: ?>
	                   	<?php echo Form::button('<i class="fa fa-arrow-circle-up" aria-hidden="true"></i>' ,['class' => 'btn btn-danger btn-xs data-active-btn','data-href' => '/admin/active-user/'.$row->id ]); ?>

	                   <?php endif; ?>
	                   </span>
	                   <?php endif; ?>
	                   <?php if($can_edit): ?>
	                   <a href="<?php echo e(url('/admin/edit-user/'.$row->id)); ?>" class="btn btn-info btn-xs data-edit-btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
	                   <?php endif; ?>
	                   </td>
	                   <?php endif; ?>
					</tr>
				 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 	<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>