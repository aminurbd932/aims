<style type="text/css">
  .custom_message {
        padding: 5px 30px;
    margin-bottom: 5px;
    margin-top: 5px;
  }
</style>
<?php if(session('success') || session('unsuccess') || session('error') || $errors->any()): ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
     <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible custom_message">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    		
    <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible custom_message">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>
   			 
    <?php if(session('unsuccess')): ?>
      <div class="alert alert-warning alert-dismissible custom_message">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <?php echo e(session('unsuccess')); ?>

      </div>
    <?php endif; ?>
   			 
    <?php if(session('error')): ?>
      <div class="alert alert-danger alert-dismissible custom_message">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>

    </div>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div id="messages" style="display: none;    padding: 5px;">
        <div class="alert fade in alert-dismissible custom_message" style="margin-bottom: 0px;">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <div id="text"></div>
        </div>
      </div>

    </div>
</div>