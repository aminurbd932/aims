 
<?php $__env->startSection('admin-content'); ?>
  <?php echo $__env->make('admin.user.permission.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <section class="content custom-content">
  <div class="row">
   	<div class="col-md-12">
      <div class="box box-body"> 
    <?php echo e(Form::open(array('url' => '/admin/update-permission/'.$record->id,'class' => 'nform-horizontal index_form', 'autocomplete' => 'off'))); ?>

   		<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
  			<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
          <?php echo Form::label('name', __('Permission Name').'*', ['class' => 'control-label required']); ?>	
          <?php echo Form::text('name', $record->name, ['class' => 'form-control input-sm', 'required' => 'required']); ?>

         <span class="help-block"><?php echo e($errors -> first('name')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
		    <div class="form-group <?php echo e($errors->has('display_name') ? ' has-error' : ''); ?>">
          <?php echo Form::label('display_name', __('Display Name').'*', ['class' => 'control-label required']); ?>	
          <?php echo Form::text('display_name', $record->display_name, ['class' => 'form-control bn input-sm', 'required' => 'required']); ?>

         <span class="help-block"><?php echo e($errors -> first('display_name')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
          <?php echo Form::label('description', __('Description'), ['class' => 'control-label']); ?> 
          <?php echo Form::text('description', $record->description, ['class' => 'form-control bn input-sm']); ?>

         <span class="help-block"><?php echo e($errors -> first('description')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <div class="form-group <?php echo e($errors->has('role_id') ? ' has-error' : ''); ?>">
          <?php echo Form::label('role_id', __('Role Name'), ['class' => 'control-label']); ?> 
          <br>
          <?php if($role_name): ?>
            <?php $__currentLoopData = $role_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key  => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(isset($assign_role[$role->id])): ?>
              <?php echo Form::checkbox('role_id[]', 1, $role->id); ?>&nbsp;&nbsp;<?php echo $role->name ?>
              <?php else: ?>
                <?php echo Form::checkbox('role_id[]' ,$role->id); ?>&nbsp;&nbsp;<?php echo $role->name ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
         <span class="help-block"><?php echo e($errors -> first('role_id')); ?></span>
        </div>
      </div>
      <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 text-center save_top">
   			<div class="form-group">
     		  <?php echo Form::button(__('Update'), ['type' => 'submit', 'class' => 'btn btn-primary btn-sm save-btn']); ?>

     		  <?php echo Form::reset(__('Reset'), ['class' => 'btn btn-warning btn-sm reset-btn']); ?>

        </div>
      </div>
   	<?php echo e(Form::close()); ?>

    </div>
    </div>
   	</div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('../admin/admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>