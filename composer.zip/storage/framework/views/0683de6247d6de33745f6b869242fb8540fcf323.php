<?php $__env->startSection('admin-content'); ?>
<?php echo $__env->make('admin.user.permission.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<section class="content custom-content">
		<?php echo $__env->make('admin.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if (\Entrust::can('user-permission-create')) : ?>
	 <div class="box-header with-border">
	    <h3 class="box-title">
	          <a href="<?php echo e(url('/admin/add-permission')); ?>" class="btn bg-navy btn-flat"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;New Add</a>
	    </h3>
	 </div>
	 <?php endif; // Entrust::can ?>
	<div class="row list-container" id="search_result">
		<?php echo $__env->make('admin.user.permission.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../admin/admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>