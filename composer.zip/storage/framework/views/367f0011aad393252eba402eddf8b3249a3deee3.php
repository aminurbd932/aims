<section class="content-header">
      <h1 class="custom-breadcum">
        User
        <small><?php echo e($bc_title); ?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> User</a></li>
        <li><a href="<?php echo e(url('/admin/user')); ?>"></i> User</a></li>
        <li class="active">User <?php echo e($bc_title); ?></li>
      </ol>
</section>