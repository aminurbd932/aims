 
<?php $__env->startSection('admin-content'); ?>
  <?php echo $__env->make('admin.setup.config.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <section class="content custom-content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-body"> 
    <?php echo e(Form::open(array('url' => '/admin/update-config','class' => 'nform-horizontal index_form', 'autocomplete' => 'off', 'files' => true))); ?>

      <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
          <?php echo Form::label('name', __('Shop Name').'*', ['class' => 'control-label required']); ?> 
          <?php echo Form::text('name', $record[0]->name, ['class' => 'form-control input-sm', 'required' => 'required']); ?>

          <?php echo Form::hidden('id', $record[0]->id, ['class' => 'form-control input-sm', 'required' => 'required']); ?>

         <span class="help-block"><?php echo e($errors -> first('name')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <div class="form-group <?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
          <?php echo Form::label('mobile', __('Mobile').'*', ['class' => 'control-label required']); ?>  
          <?php echo Form::text('mobile', $record[0]->mobile, ['class' => 'form-control bn input-sm', 'required' => 'required']); ?>

         <span class="help-block"><?php echo e($errors -> first('mobile')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
          <?php echo Form::label('phone', __('Phone'), ['class' => 'control-label']); ?>  
          <?php echo Form::text('phone', $record[0]->phone, ['class' => 'form-control bn input-sm']); ?>

         <span class="help-block"><?php echo e($errors -> first('phone')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
        <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
          <?php echo Form::label('email', __('Email'), ['class' => 'control-label']); ?> 
          <?php echo Form::text('email', $record[0]->email, ['class' => 'form-control bn input-sm']); ?>

         <span class="help-block"><?php echo e($errors -> first('email')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-8 col-lg-8">
        <div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
          <?php echo Form::label('address', __('Address').'*', ['class' => 'control-label required']); ?> 
          <?php echo Form::text('address', $record[0]->address, ['class' => 'form-control bn input-sm', 'required' => 'required']); ?>

         <span class="help-block"><?php echo e($errors -> first('address')); ?></span>
        </div>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-4 col-lg-4">
        <div class="form-group <?php echo e($errors->has('logo') ? ' has-error' : ''); ?>">
          <?php echo Form::label('logo', __('Logo'), ['class' => 'control-label' ,'style' => 'display:block']); ?> 
          <span> 
          <?php echo Form::file('logo', ['class' => 'form-control bn input-sm', 'style' => 'width:100px;float:left;margin-right: 10px;']); ?>

          <img width="140px" height="160px" src="<?php echo e(asset($record[0]->logo)); ?>">
          </span>
          
         <span class="help-block"><?php echo e($errors -> first('logo')); ?></span>
        </div>
      </div>
      <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 text-center save_top">
        <div class="form-group">
          <?php echo Form::button(__('Update'), ['type' => 'submit', 'class' => 'btn btn-primary btn-sm save-btn']); ?>

          <?php echo Form::reset(__('Reset'), ['class' => 'btn btn-warning btn-sm reset-btn']); ?>

        </div>
      </div>
    <?php echo e(Form::close()); ?>

    </div>
    </div>
    </div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('../admin/admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>