<?php 
	$can_view = Entrust::can('user-permission-view');
	$can_edit = Entrust::can('user-permission-edit');
	$can_delete = Entrust::can('user-permission-delete');
?>
<div class="col-md-12">
	<div class="box">
		<div class="box-body">
			<table class="table table-bordered">
				<tbody>
					<tr class="active">
					  <th>#</th>
					  <th>Permission Name</th>
					  <th>Display Name</th>
					  <th>Description</th>
					  <?php if($can_view || $can_edit || $can_delete): ?>
					  <th>Action</th>
					  <?php endif; ?>
					</tr>
					<?php if($records): ?>
					<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="<?php echo e((($key+1) % 2 == 0) ? 'success' : 'primary'); ?>">
					  <td><?php echo e($key+1); ?></td>
					  <td><?php echo e($row->name); ?></td>
					  <td><?php echo e($row->display_name); ?></td>
					  <td><?php echo e($row->description); ?></td>
					  <?php if($can_view || $can_edit || $can_delete): ?>
	                   <td style="text-align: center;width: 100px;">
	                   <?php if($can_view): ?>
	                   <?php echo Form::button('<i class="fa fa-eye" aria-hidden="true"></i>' ,['class' => 'btn btn-sucess btn-xs data-view-btn','data-href' => '/admin/view-permission/'.$row->id ]); ?>

	                   <?php endif; ?>
	                   <?php if($can_edit): ?>
	                   <a href="<?php echo e(url('/admin/edit-permission/'.$row->id)); ?>" class="btn btn-info btn-xs data-edit-btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
	                   <?php endif; ?>
	                   <?php if($can_delete): ?>
	                   <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i>' ,['class' => 'btn btn-danger btn-xs data-delete-btn','data-href' => '/admin/delete-permission/'.$row->id ]); ?>

	                   <?php endif; ?>
	                   </td>
	                   <?php endif; ?>
					</tr>
				 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 	<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>