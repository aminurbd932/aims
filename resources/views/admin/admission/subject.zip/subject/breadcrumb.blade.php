<section class="content-header">
      <h1 class="custom-breadcum">
        Admission Exam Subject
        <small>{{ $bc_title }}</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/admission-subject')}}"></i> Admission Exam Subject</a></li>
        <li class="active">Admission Exam Subject {{ $bc_title }}</li>
      </ol>
</section>