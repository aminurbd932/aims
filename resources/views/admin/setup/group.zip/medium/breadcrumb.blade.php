<section class="content-header">
    <h1 class="custom-breadcum">
        Medium
        <small>{{ $bc_title }}</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="{{url('/admin/dashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href=""></i> Setup</a></li>
        <li><a href="{{url('/admin/medium')}}"></i> Medium</a></li>
        <li class="active">Medium {{ $bc_title }}</li>
    </ol>
</section>